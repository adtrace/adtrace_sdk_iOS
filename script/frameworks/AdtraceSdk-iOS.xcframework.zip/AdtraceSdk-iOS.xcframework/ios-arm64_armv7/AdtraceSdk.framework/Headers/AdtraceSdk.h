







#import <UIKit/UIKit.h>


FOUNDATION_EXPORT double AdtraceSdkVersionNumber;


FOUNDATION_EXPORT const unsigned char AdtraceSdkVersionString[];



#import <AdtraceSdk/Adtrace.h>
#import <AdtraceSdk/ADTEvent.h>
#import <AdtraceSdk/ADTThirdPartySharing.h>
#import <AdtraceSdk/ADTConfig.h>
#import <AdtraceSdk/ADTLogger.h>
#import <AdtraceSdk/ADTAttribution.h>
#import <AdtraceSdk/ADTSubscription.h>
#import <AdtraceSdk/ADTEventSuccess.h>
#import <AdtraceSdk/ADTEventFailure.h>
#import <AdtraceSdk/ADTSessionSuccess.h>
#import <AdtraceSdk/ADTSessionFailure.h>
#import <AdtraceSdk/ADTAdRevenue.h>
#import <AdtraceSdk/ADTLinkResolution.h>
